"""CareerTrack - multi-user Flask app with email OTP authentication."""
import os
import secrets
import smtplib
import sqlite3
from datetime import datetime, timedelta
from email.message import EmailMessage

from flask import Flask, g, jsonify, render_template, request, redirect, session, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("CAREERTRACK_DB", os.path.join(BASE_DIR, "careertrack.db"))
SECRET_KEY = os.environ.get("CAREERTRACK_SECRET_KEY", "change-this-local-development-secret")
STATUSES = ["Wishlist", "Applied", "Interview", "Offer", "Rejected"]
TYPES = ["Internship", "Full-time", "Part-time", "Contract"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    is_verified INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS otp_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    code_hash TEXT NOT NULL,
    purpose TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    company TEXT NOT NULL,
    role TEXT NOT NULL,
    job_type TEXT NOT NULL DEFAULT 'Internship',
    status TEXT NOT NULL DEFAULT 'Applied',
    location TEXT DEFAULT '',
    link TEXT DEFAULT '',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    applied_on TEXT,
    interview_at TEXT,
    reminder_minutes INTEGER NOT NULL DEFAULT 60,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
"""

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    # Add user_id to legacy applications table if this is an existing installation.
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL,
      is_verified INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS otp_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, code_hash TEXT NOT NULL,
      purpose TEXT NOT NULL, expires_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)
    existing = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='applications'").fetchone()
    if not existing:
        conn.executescript(SCHEMA)
    else:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(applications)")}
        if "user_id" not in cols:
            conn.execute("ALTER TABLE applications ADD COLUMN user_id INTEGER")
    conn.commit()
    conn.close()


def send_otp(email, code, purpose):
    """Send OTP by SMTP when configured. In local development, return code for display."""
    host = os.environ.get("CAREERTRACK_SMTP_HOST")
    user = os.environ.get("CAREERTRACK_SMTP_USER")
    password = os.environ.get("CAREERTRACK_SMTP_PASSWORD")
    from_email = os.environ.get("CAREERTRACK_FROM_EMAIL", user or "")
    if host and user and password and from_email:
        msg = EmailMessage()
        msg["Subject"] = "Your CareerTrack verification code"
        msg["From"] = from_email
        msg["To"] = email
        msg.set_content(
            f"Your CareerTrack {purpose} code is {code}.\n"
            "It expires in 10 minutes. If you did not request this code, ignore this email."
        )
        port = int(os.environ.get("CAREERTRACK_SMTP_PORT", "587"))
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.starttls()
            server.login(user, password)
            server.send_message(msg)
        return None
    # Local-only convenience: OTP is shown in the browser when email is not configured.
    app.logger.warning("SMTP not configured; local development OTP for %s: %s", email, code)
    return code


def issue_otp(user_id, email, purpose):
    db = get_db()
    now = datetime.utcnow()
    # Limit OTP generation to 5 per hour per account.
    recent = db.execute(
        "SELECT COUNT(*) FROM otp_codes WHERE user_id=? AND created_at >= ?",
        (user_id, (now - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"))
    ).fetchone()[0]
    if recent >= 5:
        raise ValueError("Too many codes requested. Please try again in an hour.")
    code = f"{secrets.randbelow(1_000_000):06d}"
    db.execute("DELETE FROM otp_codes WHERE user_id=? AND purpose=?", (user_id, purpose))
    db.execute(
        "INSERT INTO otp_codes(user_id,code_hash,purpose,expires_at) VALUES(?,?,?,?)",
        (user_id, generate_password_hash(code), purpose, (now + timedelta(minutes=10)).isoformat())
    )
    db.commit()
    dev_code = send_otp(email, code, purpose)
    return dev_code


def verify_otp(user_id, code, purpose):
    db = get_db()
    row = db.execute(
        "SELECT * FROM otp_codes WHERE user_id=? AND purpose=? ORDER BY id DESC LIMIT 1",
        (user_id, purpose)
    ).fetchone()
    if not row:
        return False, "Request a new verification code."
    if datetime.utcnow() > datetime.fromisoformat(row["expires_at"]):
        db.execute("DELETE FROM otp_codes WHERE id=?", (row["id"],))
        db.commit()
        return False, "That code has expired. Request a new one."
    if row["attempts"] >= 5:
        db.execute("DELETE FROM otp_codes WHERE id=?", (row["id"],))
        db.commit()
        return False, "Too many incorrect attempts. Request a new code."
    if not check_password_hash(row["code_hash"], (code or "").strip()):
        db.execute("UPDATE otp_codes SET attempts=attempts+1 WHERE id=?", (row["id"],))
        db.commit()
        return False, "Incorrect verification code."
    db.execute("DELETE FROM otp_codes WHERE id=?", (row["id"],))
    db.commit()
    return True, None


def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "Please log in to continue."}), 401
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper


def validate(data):
    company = (data.get("company") or "").strip()
    role = (data.get("role") or "").strip()
    if not company or not role:
        return None, "Company and role are required."
    status = data.get("status") or "Applied"
    if status not in STATUSES:
        return None, f"Status must be one of {', '.join(STATUSES)}."
    job_type = data.get("job_type") or "Internship"
    if job_type not in TYPES:
        return None, f"Job type must be one of {', '.join(TYPES)}."
    interview_at = (data.get("interview_at") or "").strip() or None
    if interview_at:
        try: datetime.fromisoformat(interview_at)
        except ValueError: return None, "Interview date/time is invalid."
    applied_on = (data.get("applied_on") or "").strip() or None
    if applied_on:
        try: datetime.fromisoformat(applied_on)
        except ValueError: return None, "Applied date is invalid."
    link = (data.get("link") or "").strip()
    if link and not link.lower().startswith(("http://", "https://")): link = "https://" + link
    try: reminder = int(data.get("reminder_minutes", 60))
    except (TypeError, ValueError): return None, "Reminder must be a number of minutes."
    if reminder < 0: return None, "Reminder must not be negative."
    return {
        "company": company, "role": role, "job_type": job_type, "status": status,
        "location": (data.get("location") or "").strip(), "link": link,
        "description": (data.get("description") or "").strip(), "notes": (data.get("notes") or "").strip(),
        "applied_on": applied_on, "interview_at": interview_at, "reminder_minutes": reminder,
    }, None


@app.route("/")
@login_required
def index():
    user = get_db().execute("SELECT name,email FROM users WHERE id=?", (session["user_id"],)).fetchone()
    return render_template("index.html", statuses=STATUSES, types=TYPES, user_name=user["name"] if user else "")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("auth.html", mode="register")
    name = (request.form.get("name") or "").strip()
    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password") or ""
    if not name or not email or "@" not in email:
        flash("Enter your name and a valid email address.", "error")
        return render_template("auth.html", mode="register"), 400
    if len(password) < 8:
        flash("Password must be at least 8 characters.", "error")
        return render_template("auth.html", mode="register"), 400
    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
    if existing:
        flash("An account with this email already exists. Please log in.", "error")
        return render_template("auth.html", mode="register"), 409
    cur = db.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                     (name, email, generate_password_hash(password)))
    db.commit()
    user_id = cur.lastrowid
    try:
        dev_code = issue_otp(user_id, email, "account verification")
    except Exception as exc:
        app.logger.exception("Could not send verification email")
        flash(f"Could not send OTP: {exc}", "error")
        return render_template("auth.html", mode="register"), 500
    session["pending_user_id"] = user_id
    session["pending_purpose"] = "verify"
    session["dev_otp"] = dev_code
    session["otp_email"] = email
    return redirect(url_for("verify"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        if session.get("user_id"): return redirect(url_for("index"))
        return render_template("auth.html", mode="login")
    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password") or ""
    user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not user or not check_password_hash(user["password_hash"], password):
        flash("Email or password is incorrect.", "error")
        return render_template("auth.html", mode="login"), 401
    if not user["is_verified"]:
        try:
            dev_code = issue_otp(user["id"], user["email"], "account verification")
        except Exception as exc:
            flash(str(exc), "error")
            return render_template("auth.html", mode="login"), 429
        session["pending_user_id"] = user["id"]
        session["pending_purpose"] = "verify"
        session["dev_otp"] = dev_code
        session["otp_email"] = user["email"]
        return redirect(url_for("verify"))
    try:
        dev_code = issue_otp(user["id"], user["email"], "login")
    except Exception as exc:
        flash(str(exc), "error")
        return render_template("auth.html", mode="login"), 429
    session["pending_user_id"] = user["id"]
    session["pending_purpose"] = "login"
    session["dev_otp"] = dev_code
    session["otp_email"] = user["email"]
    return redirect(url_for("verify"))


@app.route("/verify-otp", methods=["GET", "POST"])
def verify():
    user_id = session.get("pending_user_id")
    purpose = session.get("pending_purpose")
    if not user_id or purpose not in ("verify", "login"):
        return redirect(url_for("login"))
    if request.method == "GET":
        return render_template("verify_otp.html", email=session.get("otp_email"),
                               dev_otp=session.get("dev_otp"))
    ok, error = verify_otp(user_id, request.form.get("otp"), "account verification" if purpose == "verify" else "login")
    if not ok:
        flash(error, "error")
        return render_template("verify_otp.html", email=session.get("otp_email"),
                               dev_otp=session.get("dev_otp")), 400
    db = get_db()
    if purpose == "verify":
        db.execute("UPDATE users SET is_verified=1 WHERE id=?", (user_id,))
        db.commit()
    user = db.execute("SELECT id,name FROM users WHERE id=?", (user_id,)).fetchone()
    session.clear()
    session["user_id"] = user["id"]
    session["user_name"] = user["name"]
    return redirect(url_for("index"))


@app.post("/resend-otp")
def resend_otp():
    user_id = session.get("pending_user_id")
    purpose = session.get("pending_purpose")
    if not user_id or purpose not in ("verify", "login"):
        return redirect(url_for("login"))
    user = get_db().execute("SELECT email FROM users WHERE id=?", (user_id,)).fetchone()
    try:
        dev_code = issue_otp(user_id, user["email"], "account verification" if purpose == "verify" else "login")
    except Exception as exc:
        flash(str(exc), "error")
        return redirect(url_for("verify"))
    session["dev_otp"] = dev_code
    flash("A new code has been sent.", "success")
    return redirect(url_for("verify"))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def owned_application(app_id):
    return get_db().execute("SELECT * FROM applications WHERE id=? AND user_id=?",
                            (app_id, session["user_id"])).fetchone()


@app.get("/api/applications")
@login_required
def list_applications():
    rows = get_db().execute(
        "SELECT * FROM applications WHERE user_id=? ORDER BY COALESCE(applied_on, created_at) DESC, id DESC",
        (session["user_id"],)).fetchall()
    return jsonify([dict(r) for r in rows])


@app.post("/api/applications")
@login_required
def create_application():
    clean, err = validate(request.get_json(silent=True) or {})
    if err: return jsonify({"error": err}), 400
    if clean["status"] != "Wishlist" and not clean["applied_on"]:
        clean["applied_on"] = datetime.now().date().isoformat()
    clean["user_id"] = session["user_id"]
    db = get_db()
    cols = ", ".join(clean)
    marks = ", ".join("?" for _ in clean)
    cur = db.execute(f"INSERT INTO applications ({cols}) VALUES ({marks})", list(clean.values()))
    db.commit()
    row = db.execute("SELECT * FROM applications WHERE id=? AND user_id=?",
                     (cur.lastrowid, session["user_id"])).fetchone()
    return jsonify(dict(row)), 201


@app.put("/api/applications/<int:app_id>")
@login_required
def update_application(app_id):
    db = get_db()
    if not owned_application(app_id): return jsonify({"error": "Not found"}), 404
    clean, err = validate(request.get_json(silent=True) or {})
    if err: return jsonify({"error": err}), 400
    sets = ", ".join(f"{k} = ?" for k in clean)
    db.execute(f"UPDATE applications SET {sets}, updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?",
               list(clean.values()) + [app_id, session["user_id"]])
    db.commit()
    return jsonify(dict(owned_application(app_id)))


@app.delete("/api/applications/<int:app_id>")
@login_required
def delete_application(app_id):
    cur = get_db().execute("DELETE FROM applications WHERE id=? AND user_id=?",
                           (app_id, session["user_id"]))
    get_db().commit()
    if cur.rowcount == 0: return jsonify({"error": "Not found"}), 404
    return jsonify({"ok": True})


@app.get("/api/stats")
@login_required
def stats():
    rows = get_db().execute("SELECT status,interview_at FROM applications WHERE user_id=?",
                            (session["user_id"],)).fetchall()
    counts = {s: 0 for s in STATUSES}
    for r in rows: counts[r["status"]] += 1
    total = len(rows)
    submitted = total - counts["Wishlist"]
    reached_interview = counts["Interview"] + counts["Offer"] + sum(
        1 for r in rows if r["status"] == "Rejected" and r["interview_at"])
    def pct(n): return round(100*n/submitted, 1) if submitted else 0.0
    return jsonify({"total": total, "submitted": submitted, "counts": counts,
                    "interview_rate": pct(reached_interview), "offer_rate": pct(counts["Offer"]),
                    "rejection_rate": pct(counts["Rejected"]), "pending": counts["Applied"]})


@app.get("/api/reminders")
@login_required
def reminders():
    now = datetime.now()
    rows = get_db().execute(
        "SELECT id,company,role,interview_at,reminder_minutes,link FROM applications "
        "WHERE user_id=? AND interview_at IS NOT NULL AND status IN ('Interview','Applied') ORDER BY interview_at",
        (session["user_id"],)).fetchall()
    out = []
    for r in rows:
        when = datetime.fromisoformat(r["interview_at"])
        if now-timedelta(hours=2) <= when <= now+timedelta(days=14):
            item = dict(r)
            item["minutes_until"] = int((when-now).total_seconds()//60)
            out.append(item)
    return jsonify(out)


init_db()

if __name__ == "__main__":
    app.run(debug=True)
