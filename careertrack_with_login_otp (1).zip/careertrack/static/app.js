(() => {
  const STATUSES = ["Wishlist", "Applied", "Interview", "Offer", "Rejected"];
  const COLORS = {
    Wishlist: "var(--wishlist)", Applied: "var(--applied)", Interview: "var(--interview)",
    Offer: "var(--offer)", Rejected: "var(--rejected)",
  };

  const $ = (s) => document.querySelector(s);
  const state = { apps: [], reminders: [] };
  const notified = new Set(JSON.parse(localStorage.getItem("ct_notified") || "[]"));

  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  async function api(url, opts = {}) {
    const res = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...opts,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
  }

  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (t.hidden = true), 2600);
  }

  const fmtDate = (d) => (d ? new Date(d + (d.length === 10 ? "T00:00" : "")).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "—");
  const fmtDateTime = (d) => (d ? new Date(d).toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "—");

  function relative(mins) {
    if (mins < 0) return `started ${Math.abs(mins)} min ago`;
    if (mins < 60) return `in ${mins} min`;
    if (mins < 1440) return `in ${Math.round(mins / 60)} h`;
    return `in ${Math.round(mins / 1440)} d`;
  }

  /* ---------- data ---------- */
  async function load() {
    const [apps, stats, reminders] = await Promise.all([
      api("/api/applications"), api("/api/stats"), api("/api/reminders"),
    ]);
    state.apps = apps;
    state.reminders = reminders;
    renderStats(stats);
    renderReminders();
    renderTable();
    checkReminders();
  }

  /* ---------- rendering ---------- */
  function renderStats(s) {
    const cards = [
      ["Total", s.total, "var(--primary)"],
      ["Applied", s.counts.Applied, COLORS.Applied],
      ["Interviews", s.counts.Interview, COLORS.Interview],
      ["Offers", s.counts.Offer, COLORS.Offer],
      ["Rejections", s.counts.Rejected, COLORS.Rejected],
    ];
    $("#statCards").innerHTML = cards
      .map(([l, n, c]) => `<div class="stat" style="--c:${c}"><div class="num">${n}</div><div class="label">${l}</div></div>`)
      .join("");

    const max = Math.max(1, ...STATUSES.map((k) => s.counts[k]));
    $("#funnel").innerHTML = STATUSES.map(
      (k) => `<div class="funnel-row">
        <span>${k}</span>
        <div class="bar-track"><div class="bar" style="--c:${COLORS[k]};width:${(s.counts[k] / max) * 100}%"></div></div>
        <b>${s.counts[k]}</b></div>`
    ).join("");

    $("#rateList").innerHTML = `
      <li><span>Interview rate</span><b>${s.interview_rate}%</b></li>
      <li><span>Offer rate</span><b>${s.offer_rate}%</b></li>
      <li><span>Rejection rate</span><b>${s.rejection_rate}%</b></li>
      <li><span class="muted">Based on ${s.submitted} submitted</span><span></span></li>`;
    $("#donut").innerHTML = donut(s);
  }

  function donut(s) {
    const size = 140, r = 52, c = 2 * Math.PI * r;
    const parts = STATUSES.filter((k) => s.counts[k] > 0).map((k) => [k, s.counts[k]]);
    const total = parts.reduce((a, [, n]) => a + n, 0);
    let offset = 0;
    const rings = parts.map(([k, n]) => {
      const len = (n / total) * c;
      const el = `<circle cx="70" cy="70" r="${r}" fill="none" stroke="${COLORS[k]}" stroke-width="18"
        stroke-dasharray="${len} ${c - len}" stroke-dashoffset="${-offset}" transform="rotate(-90 70 70)"><title>${k}: ${n}</title></circle>`;
      offset += len;
      return el;
    }).join("");
    const track = `<circle cx="70" cy="70" r="${r}" fill="none" stroke="var(--border)" stroke-width="18" ${total ? 'opacity=".4"' : ""}/>`;
    return `<svg width="${size}" height="${size}" viewBox="0 0 140 140" role="img" aria-label="Applications by status">
      ${track}${rings}
      <text x="70" y="72" text-anchor="middle" class="donut-label">${s.offer_rate}%</text>
      <text x="70" y="90" text-anchor="middle" class="donut-sub">offer rate</text></svg>`;
  }

  function renderReminders() {
    const el = $("#reminderList");
    if (!state.reminders.length) {
      el.innerHTML = `<li><span class="muted">No upcoming interviews in the next 14 days.</span></li>`;
      return;
    }
    el.innerHTML = state.reminders.map((r) => `
      <li class="${r.minutes_until <= r.reminder_minutes ? "soon" : ""}">
        <span><b>${esc(r.company)}</b> · ${esc(r.role)}</span>
        <span class="when">${fmtDateTime(r.interview_at)} · ${relative(r.minutes_until)}</span>
      </li>`).join("");
  }

  function filtered() {
    const q = $("#search").value.trim().toLowerCase();
    const st = $("#filterStatus").value;
    const ty = $("#filterType").value;
    return state.apps.filter((a) =>
      (!st || a.status === st) &&
      (!ty || a.job_type === ty) &&
      (!q || [a.company, a.role, a.notes, a.location, a.description].join(" ").toLowerCase().includes(q))
    );
  }

  function renderTable() {
    const list = filtered();
    $("#empty").hidden = state.apps.length > 0;
    $("#rows").innerHTML = list.map((a) => `
      <tr>
        <td><b>${esc(a.company)}</b>${a.location ? `<div class="sub">${esc(a.location)}</div>` : ""}</td>
        <td>${a.link ? `<a href="${esc(a.link)}" target="_blank" rel="noopener noreferrer">${esc(a.role)}</a>` : esc(a.role)}</td>
        <td>${esc(a.job_type)}</td>
        <td><span class="badge s-${esc(a.status)}">${esc(a.status)}</span></td>
        <td>${fmtDate(a.applied_on)}</td>
        <td>${fmtDateTime(a.interview_at)}</td>
        <td><div class="row-actions">
          <button class="btn small" data-edit="${a.id}">Edit</button>
          <button class="btn small danger" data-del="${a.id}">Delete</button>
        </div></td>
      </tr>`).join("");
  }

  /* ---------- form ---------- */
  const dialog = $("#dialog");
  const form = $("#form");

  function openForm(app) {
    form.reset();
    $("#formError").hidden = true;
    $("#dialogTitle").textContent = app ? "Edit application" : "New application";
    if (app) {
      for (const [k, v] of Object.entries(app)) {
        if (form.elements[k]) form.elements[k].value = v ?? "";
      }
    } else {
      form.elements.id.value = "";
      form.elements.applied_on.value = new Date().toISOString().slice(0, 10);
    }
    dialog.showModal();
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    const id = data.id;
    delete data.id;
    data.reminder_minutes = Number(data.reminder_minutes);
    try {
      if (id) await api(`/api/applications/${id}`, { method: "PUT", body: data });
      else await api("/api/applications", { method: "POST", body: data });
      dialog.close();
      toast(id ? "Application updated" : "Application added");
      load();
    } catch (err) {
      const box = $("#formError");
      box.textContent = err.message;
      box.hidden = false;
    }
  });

  $("#cancelBtn").addEventListener("click", () => dialog.close());
  $("#addBtn").addEventListener("click", () => openForm(null));

  $("#rows").addEventListener("click", async (e) => {
    const edit = e.target.closest("[data-edit]");
    const del = e.target.closest("[data-del]");
    if (edit) openForm(state.apps.find((a) => a.id === Number(edit.dataset.edit)));
    if (del && confirm("Delete this application?")) {
      await api(`/api/applications/${del.dataset.del}`, { method: "DELETE" });
      toast("Deleted");
      load();
    }
  });

  ["#search", "#filterStatus", "#filterType"].forEach((s) => $(s).addEventListener("input", renderTable));

  /* ---------- reminders ---------- */
  function updateNotifyBtn() {
    const b = $("#notifyBtn");
    if (!("Notification" in window)) { b.hidden = true; return; }
    if (Notification.permission === "granted") { b.textContent = "Reminders on ✓"; b.disabled = true; }
    else if (Notification.permission === "denied") { b.textContent = "Reminders blocked"; b.disabled = true; }
  }
  $("#notifyBtn").addEventListener("click", async () => {
    await Notification.requestPermission();
    updateNotifyBtn();
  });

  function checkReminders() {
    for (const r of state.reminders) {
      const key = `${r.id}@${r.interview_at}`;
      const due = r.minutes_until <= r.reminder_minutes && r.minutes_until >= -30;
      if (!due || notified.has(key)) continue;
      notified.add(key);
      localStorage.setItem("ct_notified", JSON.stringify([...notified]));
      const msg = `${r.company} — ${r.role} (${relative(r.minutes_until)})`;
      toast("Interview reminder: " + msg);
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("Interview reminder", { body: msg });
      }
    }
  }

  updateNotifyBtn();
  load();
  setInterval(() => api("/api/reminders").then((r) => { state.reminders = r; renderReminders(); checkReminders(); }), 60000);
})();
