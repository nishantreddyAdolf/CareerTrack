# CareerTrack — Internship & Job Tracker

CareerTrack is a multi-user job application tracker built with HTML, CSS, JavaScript, Flask, and SQLite.

## Features

- Account registration with name, email, and password
- Email OTP verification for new accounts and every login
- Passwords stored as secure hashes (not plain text)
- OTP expiry after 10 minutes, attempt limits, and resend rate limits
- Private per-user applications, analytics, and interview reminders
- Job application CRUD, status pipeline, search, and filters

## Run on Windows (VS Code)

Open a terminal in this folder, then run:

```powershell
python -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe app.py
```

Using the virtual environment's Python directly avoids PowerShell activation-policy issues. Open http://127.0.0.1:5000.

## OTP email setup

For local testing, if SMTP is not configured, CareerTrack shows a development OTP on the verification page and logs it in the terminal. **This fallback is for local development only. Do not deploy with this fallback enabled.**

To send actual OTP emails, set these environment variables before running Flask:

- `CAREERTRACK_SMTP_HOST` — SMTP server hostname
- `CAREERTRACK_SMTP_PORT` — usually `587`
- `CAREERTRACK_SMTP_USER` — SMTP username
- `CAREERTRACK_SMTP_PASSWORD` — SMTP password or provider app password
- `CAREERTRACK_FROM_EMAIL` — verified sender email address
- `CAREERTRACK_SECRET_KEY` — long random secret for Flask sessions

Example PowerShell setup for a terminal session (replace values with your provider's settings; never commit credentials):

```powershell
$env:CAREERTRACK_SMTP_HOST="smtp.example.com"
$env:CAREERTRACK_SMTP_PORT="587"
$env:CAREERTRACK_SMTP_USER="your-sender@example.com"
$env:CAREERTRACK_SMTP_PASSWORD="your-app-password"
$env:CAREERTRACK_FROM_EMAIL="your-sender@example.com"
$env:CAREERTRACK_SECRET_KEY="replace-with-a-long-random-secret"
.\venv\Scripts\python.exe app.py
```

Email provider SMTP settings differ. For Gmail, use an App Password if your account is eligible; do not use your normal account password.

## Database

SQLite is created automatically as `careertrack.db` beside `app.py`. It stores user names, unique emails, password hashes, OTP hashes/expiry metadata, and each user's applications. Do not share or upload the database file: it contains private data.

If you already had a database from the older single-user version, the app adds the user_id column automatically. Old applications without an owner are not shown in any new account; back up your database before experimenting.

## Security notes

- This is a learning/local project. Before public deployment, configure real SMTP, a strong secret key, HTTPS, secure cookies, CSRF protection, login/OTP rate limiting at the deployment layer, and monitoring.
- Development OTP display is intentionally enabled only when SMTP settings are absent; do not expose the local development server to the internet.
