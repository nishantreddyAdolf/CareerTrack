import os
import tempfile
from datetime import datetime, timedelta

import pytest

fd, path = tempfile.mkstemp(suffix=".db")
os.close(fd)
os.environ["CAREERTRACK_DB"] = path

import app as ct  # noqa: E402


@pytest.fixture()
def client():
    with ct.app.test_client() as c:
        yield c


def post(client, **kw):
    body = {"company": "Acme", "role": "SWE Intern", "status": "Applied"}
    body.update(kw)
    return client.post("/api/applications", json=body)


def test_index_renders(client):
    r = client.get("/")
    assert r.status_code == 200
    assert b"CareerTrack" in r.data


def test_validation(client):
    assert client.post("/api/applications", json={"company": "", "role": "x"}).status_code == 400
    assert post(client, status="Nope").status_code == 400
    assert post(client, interview_at="garbage").status_code == 400


def test_crud(client):
    r = post(client, link="acme.com/jobs")
    assert r.status_code == 201
    app_id = r.get_json()["id"]
    assert r.get_json()["link"] == "https://acme.com/jobs"
    assert r.get_json()["applied_on"]  # defaulted

    r = client.put(f"/api/applications/{app_id}", json={"company": "Acme", "role": "SWE Intern", "status": "Offer"})
    assert r.get_json()["status"] == "Offer"

    assert client.delete(f"/api/applications/{app_id}").status_code == 200
    assert client.delete(f"/api/applications/{app_id}").status_code == 404
    assert client.put(f"/api/applications/{app_id}", json={"company": "a", "role": "b"}).status_code == 404


def test_stats_and_reminders(client):
    for a in client.get("/api/applications").get_json():
        client.delete(f"/api/applications/{a['id']}")
    soon = (datetime.now() + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M")
    post(client, company="A", status="Wishlist")
    post(client, company="B", status="Applied")
    post(client, company="C", status="Interview", interview_at=soon)
    post(client, company="D", status="Offer")
    post(client, company="E", status="Rejected")

    s = client.get("/api/stats").get_json()
    assert s["total"] == 5 and s["submitted"] == 4
    assert s["interview_rate"] == 50.0  # Interview + Offer out of 4
    assert s["offer_rate"] == 25.0
    assert s["rejection_rate"] == 25.0

    rem = client.get("/api/reminders").get_json()
    assert len(rem) == 1 and rem[0]["company"] == "C"
    assert 100 <= rem[0]["minutes_until"] <= 120
